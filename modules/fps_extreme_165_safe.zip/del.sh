#!/system/bin/sh
MODULE_NAME="FPS Extreme 165 Safe"
MODULE_MODE="DEL"
TAG="PluginModule"
FAILED=0
COUNT=0
notify() { cmd notification post -S bigtext -t "$MODULE_NAME" "$TAG" "$1." >/dev/null 2>&1 || true; }
run_cmd() {
  COUNT=$((COUNT + 1))
  "$@" >/dev/null 2>&1 || FAILED=$((FAILED + 1))
}
put_setting() { run_cmd settings put "$1" "$2" "$3"; }
del_setting() { run_cmd settings delete "$1" "$2"; }
put_prop() { run_cmd setprop "$1" "$2"; }
notify "START ${MODULE_MODE}"
echo "[$MODULE_NAME] mode=$MODULE_MODE"
echo "Device: $(getprop ro.product.manufacturer) $(getprop ro.product.model)"
echo "Android: $(getprop ro.build.version.release) SDK $(getprop ro.build.version.sdk)"
del_setting "system" "display.refresh_rate"
del_setting "system" "display.low_framerate_limit"
del_setting "system" "display.large_comp_hint_fps"
del_setting "system" "display.defer_fps_frame_count"
del_setting "system" "display.enable_optimal_refresh_rate"
del_setting "system" "display.enable_idle_content_fps_hint"
del_setting "system" "display.idle_time"
del_setting "system" "display.idle_time_inactive"
del_setting "system" "disable_idle_fps"
del_setting "system" "disable_idle_fps.threshold"
del_setting "system" "fps.idle_control"
del_setting "system" "metadata_dynfps.disabel"
del_setting "system" "enable_dpps_dynamic_fps"
del_setting "system" "display.disable_dynamic_fps"
del_setting "system" "display.disable_metadata_dynamic_fps"
del_setting "system" "display.disable_mitigated_fps"
del_setting "global" "dfps.enable"
del_setting "global" "smart_dfps.enable"
del_setting "global" "smart_dfps.idle_fps"
del_setting "global" "smart_dfps.app_switch_fps"
del_setting "global" "display.idle_default_fps"
del_setting "global" "refresh_rate_mode"
del_setting "global" "refresh_rate_switching_type"
del_setting "global" "refresh_rate_force_high"
del_setting "global" "surface_flinger.use_content_detection_for_refresh_rate"
del_setting "global" "media.recorder-max-base-layer-fps"
del_setting "global" "tran_default_refresh_mode"
del_setting "global" "tran_custom_refresh_rate_config.support"
del_setting "global" "transsion.frame_override.support"
del_setting "global" "game_mode"
del_setting "global" "game_dashboard_always_on"
del_setting "global" "game_driver_all_apps"
del_setting "global" "updatable_driver_all_apps"
del_setting "global" "angle_gl_driver_all_angle"
del_setting "global" "gpu_debug_layers"
del_setting "global" "window_animation_scale"
del_setting "global" "transition_animation_scale"
del_setting "global" "animator_duration_scale"
del_setting "system" "pointer_speed"
del_setting "system" "haptic_feedback_enabled"
del_setting "system" "show_touches"
del_setting "global" "low_power"
del_setting "global" "battery_saver_constants"
del_setting "global" "adaptive_battery_management_enabled"
del_setting "global" "peak_refresh_rate"
del_setting "global" "min_refresh_rate"
del_setting "system" "peak_refresh_rate"
del_setting "system" "min_refresh_rate"
if [ "$FAILED" -eq 0 ]; then
  notify "SUCCESS"
  echo "SUCCESS: $MODULE_NAME applied ($COUNT commands)."
  exit 0
else
  notify "FALSE"
  echo "FALSE: $MODULE_NAME completed with $FAILED unsupported command(s). Device/ROM may block some parameters."
  exit 0
fi
