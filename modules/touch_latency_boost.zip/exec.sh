#!/system/bin/sh
MODULE_NAME="Touch Latency Boost"
MODULE_MODE="EXEC"
TAG="PluginModule"
FAILED=0
COUNT=0
notify() { cmd notification post -S bigtext -t "$MODULE_NAME" "$TAG" "$1." >/dev/null 2>&1 || true; }
run_cmd() {
  COUNT=$((COUNT + 1))
  "$@" >/dev/null 2>&1 || FAILED=$((FAILED + 1))
}
put_setting() { run_cmd settings put "$1" "$2" "$3"; }
del_setting() { run_cmd settings delete "$1" "$2"; }
put_prop() { run_cmd setprop "$1" "$2"; }
notify "START ${MODULE_MODE}"
echo "[$MODULE_NAME] mode=$MODULE_MODE"
echo "Device: $(getprop ro.product.manufacturer) $(getprop ro.product.model)"
echo "Android: $(getprop ro.build.version.release) SDK $(getprop ro.build.version.sdk)"
put_setting "system" "pointer_speed" "7"
put_setting "system" "touch.pressure.scale" "0.001"
put_setting "system" "long_press_timeout" "250"
put_setting "system" "tap_timeout" "80"
put_setting "system" "haptic_feedback_enabled" "0"
put_setting "secure" "show_touches" "0"
put_prop "debug.input.dispatching_timeout_millis" "5000"
put_prop "debug.sf.latch_unsignaled" "1"
put_prop "debug.hwui.render_dirty_regions" "false"
put_prop "debug.hwui.use_partial_updates" "false"
if [ "$FAILED" -eq 0 ]; then
  notify "SUCCESS"
  echo "SUCCESS: $MODULE_NAME applied ($COUNT commands)."
  exit 0
else
  notify "FALSE"
  echo "FALSE: $MODULE_NAME completed with $FAILED unsupported command(s). Device/ROM may block some parameters."
  exit 0
fi
