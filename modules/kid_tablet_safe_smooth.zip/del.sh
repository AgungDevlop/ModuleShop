#!/system/bin/sh
# Restore script for Kids Tablet Safe Smooth. Watermark: By Agung Developer
MODULE_ID="kid_tablet_safe_smooth"
MODULE_NAME="Kids Tablet Safe Smooth"
TAG="AgungDeveloper"
WATERMARK="By Agung Developer"
BACKUP_FILE="/data/local/tmp/pluginmodule_backup/${MODULE_ID}.settings"
notify() { cmd notification post -S bigtext -t "$MODULE_NAME Restore | $WATERMARK" "$TAG" "$1" >/dev/null 2>&1 || cmd notification post -t "$MODULE_NAME Restore | $WATERMARK" "$TAG" "$1" >/dev/null 2>&1 || true; }
notify "RESTORE: $MODULE_NAME restoring previous Android settings. $WATERMARK"
if [ -f "$BACKUP_FILE" ]; then
  while IFS='|' read -r ns key val; do
    [ -z "$ns" ] && continue
    if [ "$val" = "null" ] || [ -z "$val" ]; then
      settings delete "$ns" "$key" >/dev/null 2>&1 || true
    else
      settings put "$ns" "$key" "$val" >/dev/null 2>&1 || true
    fi
  done < "$BACKUP_FILE"
  notify "RESTORE DONE: previous settings restored. $WATERMARK"
  echo "RESTORE DONE: $MODULE_NAME. $WATERMARK"
else
  notify "RESTORE SKIPPED: no backup found. $WATERMARK"
  echo "No backup found for $MODULE_NAME. $WATERMARK"
fi
exit 0
