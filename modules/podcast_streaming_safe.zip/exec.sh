#!/system/bin/sh
# Podcast Streaming Safe - Safe dual-mode ADB/root helper module v2.5.
# Watermark: By Agung Developer
# Rules: no auto aim, no game memory edit, no package wipe, no thermal disable, no system/vendor writes.
MODULE_ID="podcast_streaming_safe"
MODULE_NAME="Podcast Streaming Safe"
#!/system/bin/sh
# Daily Smooth Optimizer Safe - Safe dual-mode ADB/root module v2.3.
# Watermark: By Agung Developer
# Rules: no rm -rf, no pm clear, no force-stop, no thermal disable, no system/vendor writes.
MODULE_ID="daily_smooth_optimizer_safe"
MODULE_NAME="Daily Smooth Optimizer Safe"

TAG="AgungDeveloper"
WATERMARK="By Agung Developer"
BACKUP_DIR="/data/local/tmp/pluginmodule_backup"
BACKUP_FILE="$BACKUP_DIR/${MODULE_ID}.settings"
FAILED=0
COUNT=0
ROOT_MODE=0
mkdir -p "$BACKUP_DIR" >/dev/null 2>&1 || true

if [ "$(id -u 2>/dev/null)" = "0" ]; then
  ROOT_MODE=1
elif command -v su >/dev/null 2>&1 && su -c 'id -u' 2>/dev/null | grep -q '^0$'; then
  ROOT_MODE=1
fi

notify() {
  msg="$1"
  cmd notification post -S bigtext -t "$MODULE_NAME | $WATERMARK" "$TAG" "$msg" >/dev/null 2>&1 || \
  cmd notification post -t "$MODULE_NAME | $WATERMARK" "$TAG" "$msg" >/dev/null 2>&1 || true
}
run_cmd() { COUNT=$((COUNT + 1)); "$@" >/dev/null 2>&1 || FAILED=$((FAILED + 1)); }
run_root() {
  [ "$ROOT_MODE" -eq 1 ] || return 0
  COUNT=$((COUNT + 1))
  if [ "$(id -u 2>/dev/null)" = "0" ]; then
    sh -c "$*" >/dev/null 2>&1 || FAILED=$((FAILED + 1))
  else
    su -c "$*" >/dev/null 2>&1 || FAILED=$((FAILED + 1))
  fi
}
read_setting() { settings get "$1" "$2" 2>/dev/null; }
backup_setting() {
  ns="$1"; key="$2"
  [ -f "$BACKUP_FILE" ] && grep -q "^$ns|$key|" "$BACKUP_FILE" 2>/dev/null && return 0
  val="$(read_setting "$ns" "$key")"
  echo "$ns|$key|$val" >> "$BACKUP_FILE" 2>/dev/null || true
}
put_setting_safe() {
  ns="$1"; key="$2"; val="$3"
  backup_setting "$ns" "$key"
  cur="$(read_setting "$ns" "$key")"
  [ "$cur" = "$val" ] && return 0
  run_cmd settings put "$ns" "$key" "$val"
  if [ "$ROOT_MODE" -eq 1 ]; then run_root "settings put $ns $key '$val'"; fi
}
delete_setting_safe() {
  ns="$1"; key="$2"
  backup_setting "$ns" "$key"
  run_cmd settings delete "$ns" "$key"
  if [ "$ROOT_MODE" -eq 1 ]; then run_root "settings delete $ns $key"; fi
}
apply_animation() { put_setting_safe global window_animation_scale "$1"; put_setting_safe global transition_animation_scale "$1"; put_setting_safe global animator_duration_scale "$1"; }
apply_refresh_balanced() { fps="$1"; put_setting_safe global peak_refresh_rate "$fps"; put_setting_safe system peak_refresh_rate "$fps"; put_setting_safe global min_refresh_rate 60; put_setting_safe system min_refresh_rate 60; put_setting_safe global refresh_rate_mode 1; }
apply_input_balanced() { put_setting_safe system pointer_speed "$1"; put_setting_safe system show_touches 0; put_setting_safe system haptic_feedback_enabled 1; }
apply_input_feedback_off() { put_setting_safe system sound_effects_enabled 0; put_setting_safe system lockscreen_sounds_enabled 0; }
apply_gpu_safe() { put_setting_safe global game_driver_all_apps 1; put_setting_safe global updatable_driver_all_apps 1; put_setting_safe global gpu_debug_layers 0; put_setting_safe global enable_gpu_debug_layers 0; }
apply_vulkan_safe() { put_setting_safe global game_driver_all_apps 1; }
apply_memory_low() { put_setting_safe global activity_manager_constants max_cached_processes=32; }
apply_memory_balanced() { put_setting_safe global activity_manager_constants max_cached_processes=32; }
apply_memory_high() { put_setting_safe global activity_manager_constants max_cached_processes=48; }
apply_storage_trim() { size="$1"; cmd package trim-caches "$size" >/dev/null 2>&1 || true; if [ "$ROOT_MODE" -eq 1 ]; then run_root "cmd package trim-caches $size"; run_root "sync"; fi; }
apply_storage_idle() { put_setting_safe global automatic_storage_manager_enabled 0; }
apply_dex_light() { if [ "$ROOT_MODE" -eq 1 ]; then run_root "cmd package bg-dexopt-job"; else cmd package bg-dexopt-job >/dev/null 2>&1 || true; fi; }
apply_private_dns() { host="$1"; put_setting_safe global private_dns_mode hostname; put_setting_safe global private_dns_specifier "$host"; }
apply_network_game() { put_setting_safe global mobile_data_always_on 1; put_setting_safe global wifi_scan_throttle_enabled 1; put_setting_safe global captive_portal_detection_enabled 1; }
apply_network_stream() { put_setting_safe global mobile_data_always_on 1; put_setting_safe global wifi_scan_throttle_enabled 1; }
apply_network_light() { put_setting_safe global wifi_scan_throttle_enabled 1; }
apply_mobile_stable() { put_setting_safe global mobile_data_always_on 1; put_setting_safe global network_recommendations_enabled 1; }
apply_wifi_stable() { put_setting_safe global wifi_scan_throttle_enabled 1; put_setting_safe global wifi_sleep_policy 2; }
apply_network_idle() { put_setting_safe global mobile_data_always_on 0; }
apply_battery_play() { put_setting_safe global low_power 0; put_setting_safe global adaptive_battery_management_enabled 1; }
apply_battery_idle() { put_setting_safe global adaptive_battery_management_enabled 1; put_setting_safe global app_standby_enabled 1; }
apply_battery_balanced() { put_setting_safe global adaptive_battery_management_enabled 1; put_setting_safe global low_power 0; }
apply_doze_light() { put_setting_safe global app_standby_enabled 1; put_setting_safe global forced_app_standby_enabled 1; }
apply_thermal_care() { put_setting_safe global low_power 0; put_setting_safe system screen_brightness_mode 1; }
apply_bt_audio() { put_setting_safe global bluetooth_on 1; put_setting_safe global ble_scan_always_enabled 1; }
apply_audio_stable() { put_setting_safe system sound_effects_enabled 0; put_setting_safe system haptic_feedback_enabled 1; }
apply_media_smooth() { put_setting_safe global media_metrics_mode 1; put_setting_safe system accelerometer_rotation 0; }
apply_charging_safe() { put_setting_safe global adaptive_charging_enabled 1; put_setting_safe global charging_vibration_enabled 0; }
apply_gps_maps() { put_setting_safe secure location_mode 3; put_setting_safe global assisted_gps_enabled 1; put_setting_safe global mobile_data_always_on 1; }
apply_hotspot_stable() { put_setting_safe global tether_offload_disabled 0; put_setting_safe global wifi_scan_throttle_enabled 1; }
apply_focus_light() { put_setting_safe global heads_up_notifications_enabled 1; put_setting_safe system notification_light_pulse 0; }
apply_tag_hint() { echo "Profile hint: $1" >/dev/null 2>&1 || true; }


# Extra helper profiles v2.5: safe input/display/user utility modules.
apply_touch_precision() { put_setting_safe system pointer_speed "$1"; put_setting_safe system show_touches 0; put_setting_safe system haptic_feedback_enabled "$2"; put_setting_safe system sound_effects_enabled 0; }
apply_drag_smooth() { put_setting_safe system pointer_speed 6; put_setting_safe global animator_duration_scale 0.5; put_setting_safe global window_animation_scale 0.5; }
apply_gyro_stable() { put_setting_safe system accelerometer_rotation 0; put_setting_safe system user_rotation 0; put_setting_safe system haptic_feedback_enabled 1; }
apply_scope_response() { put_setting_safe system pointer_speed 7; put_setting_safe global window_animation_scale 0; put_setting_safe global transition_animation_scale 0.5; }
apply_visual_focus() { put_setting_safe system show_touches 0; put_setting_safe system pointer_location 0; put_setting_safe system screen_brightness_mode 0; }
apply_readability() { put_setting_safe system font_scale 1.0; put_setting_safe system screen_brightness_mode 1; put_setting_safe global window_animation_scale 0.5; }
apply_screen_stable() { put_setting_safe global peak_refresh_rate "$1"; put_setting_safe system peak_refresh_rate "$1"; put_setting_safe global min_refresh_rate 60; put_setting_safe system min_refresh_rate 60; }
apply_controller_stable() { put_setting_safe global bluetooth_on 1; put_setting_safe global ble_scan_always_enabled 1; put_setting_safe system haptic_feedback_enabled 1; }
apply_call_stable() { put_setting_safe global mobile_data_always_on 1; put_setting_safe global wifi_scan_throttle_enabled 1; put_setting_safe system sound_effects_enabled 0; }
apply_creator_stable() { put_setting_safe global activity_manager_constants max_cached_processes=36; put_setting_safe global media_metrics_mode 1; }
apply_safe_privacy() { put_setting_safe secure lock_screen_show_notifications 0; put_setting_safe global heads_up_notifications_enabled 1; }
apply_notifications_reliable() { put_setting_safe global heads_up_notifications_enabled 1; put_setting_safe global notification_bubbles 1; }
apply_low_storage_guard() { put_setting_safe global automatic_storage_manager_enabled 1; cmd package trim-caches 256M >/dev/null 2>&1 || true; if [ "$ROOT_MODE" -eq 1 ]; then run_root "cmd package trim-caches 256M"; run_root "sync"; fi; }
apply_install_stable() { put_setting_safe global verifier_verify_adb_installs 1; put_setting_safe global package_verifier_enable 1; }
apply_hotspot_plus() { put_setting_safe global tether_offload_disabled 0; put_setting_safe global wifi_scan_throttle_enabled 1; put_setting_safe global mobile_data_always_on 1; }
apply_roaming_stable() { put_setting_safe global mobile_data_always_on 1; put_setting_safe global network_recommendations_enabled 1; }
apply_safe_note() { echo "Safe profile only: $1. No auto aim, no game memory edit, no package wipe. $WATERMARK" >/dev/null 2>&1 || true; }

notify "START: $MODULE_NAME running. $WATERMARK"
echo "[$MODULE_NAME] $WATERMARK"
echo "Mode: $([ "$ROOT_MODE" -eq 1 ] && echo root || echo non-root/adb-shell)"
apply_bt_audio
apply_audio_stable
apply_network_stream
apply_memory_balanced
apply_wifi_stable
if [ "$FAILED" -eq 0 ]; then
  notify "SUCCESS: applied safely in $([ "$ROOT_MODE" -eq 1 ] && echo root || echo non-root) mode. $WATERMARK"
  echo "SUCCESS: $MODULE_NAME applied safely ($COUNT commands). $WATERMARK"
else
  notify "DONE: $FAILED unsupported command(s) ignored. $WATERMARK"
  echo "DONE: $MODULE_NAME applied; $FAILED unsupported command(s) ignored. $WATERMARK"
fi
exit 0
