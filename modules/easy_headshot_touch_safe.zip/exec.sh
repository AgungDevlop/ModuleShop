#!/system/bin/sh
MODULE_ID="easy_headshot_touch_safe"
MODULE_NAME="Easy Headshot Touch Safe"
TAG="AgungDeveloper"
WATERMARK="By Agung Developer"
BACKUP_DIR="/data/local/tmp/pluginmodule_backup"
BACKUP_FILE="$BACKUP_DIR/${MODULE_ID}.settings"
FAILED=0
COUNT=0
ROOT_MODE=0
mkdir -p "$BACKUP_DIR" >/dev/null 2>&1 || true
if [ "$(id -u 2>/dev/null)" = "0" ]; then ROOT_MODE=1; elif command -v su >/dev/null 2>&1 && su -c 'id -u' 2>/dev/null | grep -q '^0$'; then ROOT_MODE=1; fi
notify() { msg="$1"; cmd notification post -S bigtext -t "$MODULE_NAME | $WATERMARK" "$TAG" "$msg" >/dev/null 2>&1 || cmd notification post -t "$MODULE_NAME | $WATERMARK" "$TAG" "$msg" >/dev/null 2>&1 || true; }
run_cmd() { COUNT=$((COUNT + 1)); "$@" >/dev/null 2>&1 || FAILED=$((FAILED + 1)); }
run_root() { [ "$ROOT_MODE" -eq 1 ] || return 0; COUNT=$((COUNT + 1)); if [ "$(id -u 2>/dev/null)" = "0" ]; then sh -c "$*" >/dev/null 2>&1 || FAILED=$((FAILED + 1)); else su -c "$*" >/dev/null 2>&1 || FAILED=$((FAILED + 1)); fi; }
read_setting() { settings get "$1" "$2" 2>/dev/null; }
backup_setting() { ns="$1"; key="$2"; [ -f "$BACKUP_FILE" ] && grep -q "^$ns|$key|" "$BACKUP_FILE" 2>/dev/null && return 0; val="$(read_setting "$ns" "$key")"; echo "$ns|$key|$val" >> "$BACKUP_FILE" 2>/dev/null || true; }
put_setting_safe() { ns="$1"; key="$2"; val="$3"; backup_setting "$ns" "$key"; cur="$(read_setting "$ns" "$key")"; [ "$cur" = "$val" ] && return 0; run_cmd settings put "$ns" "$key" "$val"; if [ "$ROOT_MODE" -eq 1 ]; then run_root "settings put $ns $key '$val'"; fi; }
set_property_safe() { prop="$1"; val="$2"; if [ "$ROOT_MODE" -eq 1 ]; then run_root "setprop $prop '$val'"; fi; }
notify "START: $MODULE_NAME. $WATERMARK"
put_setting_safe system pointer_speed 7
put_setting_safe system show_touches 0
put_setting_safe system haptic_feedback_enabled 0
put_setting_safe system sound_effects_enabled 0
put_setting_safe system lockscreen_sounds_enabled 0
put_setting_safe global window_animation_scale 0
put_setting_safe global transition_animation_scale 0
put_setting_safe global animator_duration_scale 0
put_setting_safe global peak_refresh_rate 120
put_setting_safe system peak_refresh_rate 120
put_setting_safe global min_refresh_rate 120
put_setting_safe system min_refresh_rate 120
put_setting_safe system accelerometer_rotation 0
put_setting_safe system user_rotation 0
put_setting_safe system pointer_location 0
put_setting_safe system screen_brightness_mode 0
put_setting_safe global game_driver_all_apps 1
put_setting_safe global updatable_driver_all_apps 1
put_setting_safe global angle_gl_driver_all_angle 1
put_setting_safe global mobile_data_always_on 1
put_setting_safe global wifi_scan_throttle_enabled 1
put_setting_safe global captive_portal_detection_enabled 1
put_setting_safe global low_power 0
set_property_safe debug.sf.touch_boost_refreshrate 120
set_property_safe debug.hwui.refresh_rate 120
set_property_safe debug.graphics.game_default_frame_rate 120
set_property_safe persist.sys.gpu_perf_mode 1
set_property_safe debug.sf.perf_mode 1
set_property_safe debug.hwui.disable_vsync true
run_cmd cmd power set-mode 0
if [ "$FAILED" -eq 0 ]; then notify "SUCCESS: headshot touch optimized. $WATERMARK"; echo "SUCCESS: $MODULE_NAME ($COUNT). $WATERMARK"; else notify "DONE: $FAILED ignored. $WATERMARK"; echo "DONE: $MODULE_NAME; $FAILED ignored. $WATERMARK"; fi
exit 0
