#!/system/bin/sh
MODULE_NAME="RAM Trim Safe"
MODULE_MODE="EXEC"
TAG="PluginModule"
FAILED=0
COUNT=0
notify() { cmd notification post -S bigtext -t "$MODULE_NAME" "$TAG" "$1." >/dev/null 2>&1 || true; }
run_cmd() {
  COUNT=$((COUNT + 1))
  "$@" >/dev/null 2>&1 || FAILED=$((FAILED + 1))
}
put_setting() { run_cmd settings put "$1" "$2" "$3"; }
del_setting() { run_cmd settings delete "$1" "$2"; }
put_prop() { run_cmd setprop "$1" "$2"; }
notify "START ${MODULE_MODE}"
echo "[$MODULE_NAME] mode=$MODULE_MODE"
echo "Device: $(getprop ro.product.manufacturer) $(getprop ro.product.model)"
echo "Android: $(getprop ro.build.version.release) SDK $(getprop ro.build.version.sdk)"
sh -c "cmd package trim-caches 1024M" >/dev/null 2>&1 || FAILED=$((FAILED + 1))
put_setting "global" "activity_manager_constants" "max_cached_processes=24"
put_setting "global" "cached_apps_freezer" "enabled"
put_setting "global" "window_animation_scale" "0.3"
put_setting "global" "transition_animation_scale" "0.3"
put_setting "global" "animator_duration_scale" "0.3"
put_prop "debug.hwui.drop_shadow_cache_size" "2"
put_prop "debug.hwui.gradient_cache_size" "0.5"
put_prop "debug.hwui.path_cache_size" "4"
put_prop "debug.hwui.texture_cache_size" "24"
if [ "$FAILED" -eq 0 ]; then
  notify "SUCCESS"
  echo "SUCCESS: $MODULE_NAME applied ($COUNT commands)."
  exit 0
else
  notify "FALSE"
  echo "FALSE: $MODULE_NAME completed with $FAILED unsupported command(s). Device/ROM may block some parameters."
  exit 0
fi
