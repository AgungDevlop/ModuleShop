#!/system/bin/sh
MODULE_NAME="OPPO Game Space Safe"
MODULE_MODE="EXEC"
TAG="PluginModule"
FAILED=0
COUNT=0
notify() { cmd notification post -S bigtext -t "$MODULE_NAME" "$TAG" "$1." >/dev/null 2>&1 || true; }
run_cmd() {
  COUNT=$((COUNT + 1))
  "$@" >/dev/null 2>&1 || FAILED=$((FAILED + 1))
}
put_setting() { run_cmd settings put "$1" "$2" "$3"; }
del_setting() { run_cmd settings delete "$1" "$2"; }
put_prop() { run_cmd setprop "$1" "$2"; }
notify "START ${MODULE_MODE}"
echo "[$MODULE_NAME] mode=$MODULE_MODE"
echo "Device: $(getprop ro.product.manufacturer) $(getprop ro.product.model)"
echo "Android: $(getprop ro.build.version.release) SDK $(getprop ro.build.version.sdk)"
put_setting "global" "game_mode" "1"
put_setting "global" "game_dashboard_always_on" "1"
put_setting "global" "game_driver_all_apps" "1"
put_setting "global" "updatable_driver_all_apps" "1"
put_setting "global" "angle_gl_driver_all_angle" "1"
put_setting "global" "gpu_debug_layers" "0"
put_setting "global" "window_animation_scale" "0.5"
put_setting "global" "transition_animation_scale" "0.5"
put_setting "global" "animator_duration_scale" "0.5"
put_setting "system" "pointer_speed" "7"
put_setting "system" "haptic_feedback_enabled" "0"
put_setting "system" "show_touches" "0"
put_setting "global" "low_power" "0"
put_setting "global" "battery_saver_constants" ""
put_setting "global" "adaptive_battery_management_enabled" "0"
put_prop "debug.hwui.renderer" "skiagl"
put_prop "debug.hwui.use_buffer_age" "true"
put_prop "debug.hwui.disable_vsync" "false"
put_prop "debug.hwui.profile" "false"
put_prop "debug.egl.hw" "1"
put_prop "debug.sf.hw" "1"
put_prop "debug.sf.latch_unsignaled" "1"
put_prop "debug.sf.enable_hwc_vds" "1"
put_prop "debug.sf.disable_backpressure" "1"
put_prop "debug.sf.high_fps_late_app_phase_offset_ns" "-1000000"
put_prop "debug.sf.high_fps_late_sf_phase_offset_ns" "-1000000"
put_prop "debug.gralloc.gfx_ubwc_disable" "0"
put_prop "debug.cpurend.vsync" "false"
put_prop "debug.performance.tuning" "1"
put_setting "global" "peak_refresh_rate" "120"
put_setting "global" "min_refresh_rate" "120"
put_setting "system" "peak_refresh_rate" "120"
put_setting "system" "min_refresh_rate" "120"
put_setting "global" "oppo.enable" "1"
put_setting "global" "game_space.enable" "1"
put_setting "global" "hyperboost.enable" "1"
put_setting "system" "oppo.fps" "120"
put_setting "system" "game_space.fps" "120"
put_setting "system" "hyperboost.fps" "120"
if [ "$FAILED" -eq 0 ]; then
  notify "SUCCESS"
  echo "SUCCESS: $MODULE_NAME applied ($COUNT commands)."
  exit 0
else
  notify "FALSE"
  echo "FALSE: $MODULE_NAME completed with $FAILED unsupported command(s). Device/ROM may block some parameters."
  exit 0
fi
