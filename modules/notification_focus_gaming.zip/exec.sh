#!/system/bin/sh
MODULE_NAME="Notification Focus Gaming"
MODULE_MODE="EXEC"
TAG="PluginModule"
FAILED=0
COUNT=0
notify() { cmd notification post -S bigtext -t "$MODULE_NAME" "$TAG" "$1." >/dev/null 2>&1 || true; }
run_cmd() {
  COUNT=$((COUNT + 1))
  "$@" >/dev/null 2>&1 || FAILED=$((FAILED + 1))
}
put_setting() { run_cmd settings put "$1" "$2" "$3"; }
del_setting() { run_cmd settings delete "$1" "$2"; }
put_prop() { run_cmd setprop "$1" "$2"; }
notify "START ${MODULE_MODE}"
echo "[$MODULE_NAME] mode=$MODULE_MODE"
echo "Device: $(getprop ro.product.manufacturer) $(getprop ro.product.model)"
echo "Android: $(getprop ro.build.version.release) SDK $(getprop ro.build.version.sdk)"
put_setting "global" "heads_up_notifications_enabled" "0"
put_setting "secure" "immersive_mode_confirmations" "confirmed"
put_setting "global" "zen_mode_config_etag" "game"
if [ "$FAILED" -eq 0 ]; then
  notify "SUCCESS"
  echo "SUCCESS: $MODULE_NAME applied ($COUNT commands)."
  exit 0
else
  notify "FALSE"
  echo "FALSE: $MODULE_NAME completed with $FAILED unsupported command(s). Device/ROM may block some parameters."
  exit 0
fi
