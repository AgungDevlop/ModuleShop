#!/system/bin/sh
# FPS Stability 120 Safe - Safe dual-mode ADB/root module v3.0.0-ultra-optimized.
# Watermark: By Agung Developer
# Rules: no rm -rf, no pm clear, no force-stop, no thermal disable, no system/vendor writes.
MODULE_ID="fps_stability_120_safe"
MODULE_NAME="FPS Stability 120 Safe"

TAG="AgungDeveloper"
WATERMARK="By Agung Developer"
BACKUP_DIR="/data/local/tmp/pluginmodule_backup"
BACKUP_FILE="$BACKUP_DIR/${MODULE_ID}.settings"
FAILED=0
COUNT=0
ROOT_MODE=0
mkdir -p "$BACKUP_DIR" >/dev/null 2>&1 || true

if [ "$(id -u 2>/dev/null)" = "0" ]; then
  ROOT_MODE=1
elif command -v su >/dev/null 2>&1 && su -c 'id -u' 2>/dev/null | grep -q '^0$'; then
  ROOT_MODE=1
fi

notify() {
  msg="$1"
  cmd notification post -S bigtext -t "$MODULE_NAME | $WATERMARK" "$TAG" "$msg" >/dev/null 2>&1 || \
  cmd notification post -t "$MODULE_NAME | $WATERMARK" "$TAG" "$msg" >/dev/null 2>&1 || true
}
run_cmd() { COUNT=$((COUNT + 1)); "$@" >/dev/null 2>&1 || FAILED=$((FAILED + 1)); }
run_root() {
  [ "$ROOT_MODE" -eq 1 ] || return 0
  COUNT=$((COUNT + 1))
  if [ "$(id -u 2>/dev/null)" = "0" ]; then
    sh -c "$*" >/dev/null 2>&1 || FAILED=$((FAILED + 1))
  else
    su -c "$*" >/dev/null 2>&1 || FAILED=$((FAILED + 1))
  fi
}
read_setting() { settings get "$1" "$2" 2>/dev/null; }
backup_setting() {
  ns="$1"; key="$2"
  [ -f "$BACKUP_FILE" ] && grep -q "^$ns|$key|" "$BACKUP_FILE" 2>/dev/null && return 0
  val="$(read_setting "$ns" "$key")"
  echo "$ns|$key|$val" >> "$BACKUP_FILE" 2>/dev/null || true
}
put_setting_safe() {
  ns="$1"; key="$2"; val="$3"
  backup_setting "$ns" "$key"
  cur="$(read_setting "$ns" "$key")"
  [ "$cur" = "$val" ] && return 0
  run_cmd settings put "$ns" "$key" "$val"
  if [ "$ROOT_MODE" -eq 1 ]; then run_root "settings put $ns $key '$val'"; fi
}
delete_setting_safe() {
  ns="$1"; key="$2"
  backup_setting "$ns" "$key"
  run_cmd settings delete "$ns" "$key"
  if [ "$ROOT_MODE" -eq 1 ]; then run_root "settings delete $ns $key"; fi
}
set_property_safe() {
  prop="$1"; val="$2"
  if [ "$ROOT_MODE" -eq 1 ]; then run_root "setprop $prop '$val'"; fi
}
apply_animation() { put_setting_safe global window_animation_scale "$1"; put_setting_safe global transition_animation_scale "$1"; put_setting_safe global animator_duration_scale "$1"; }
apply_animation0() { apply_animation 0; }
apply_animation05() { apply_animation 0.5; }
apply_refresh_balanced() { fps="$1"; put_setting_safe global peak_refresh_rate "$fps"; put_setting_safe system peak_refresh_rate "$fps"; put_setting_safe global min_refresh_rate 60; put_setting_safe system min_refresh_rate 60; put_setting_safe global refresh_rate_mode 1; }
apply_refresh120() {
  fps=120
  run_cmd cmd jobscheduler monitor-battery off
  run_cmd cmd jobscheduler cache-config-changes off
  run_cmd cmd power set-mode 0
  put_setting_safe global low_power 0
  put_setting_safe global peak_refresh_rate "$fps"
  put_setting_safe system peak_refresh_rate "$fps"
  put_setting_safe global min_refresh_rate "$fps"
  put_setting_safe system min_refresh_rate "$fps"
  put_setting_safe global refresh_rate_mode 1
  put_setting_safe secure user_refresh_rate "$fps"
  put_setting_safe secure miui_refresh_rate "$fps"
  put_setting_safe system min_frame_rate "$fps"
  put_setting_safe system max_frame_rate "$fps"
  put_setting_safe system tran_refresh_mode "$fps"
  put_setting_safe system last_tran_refresh_mode_in_refresh_setting "$fps"
  put_setting_safe global min_fps "$fps"
  put_setting_safe global max_fps "$fps"
  put_setting_safe system tran_need_recovery_refresh_mode "$fps"
  put_setting_safe system display_min_refresh_rate "$fps"
  put_setting_safe system max_refresh_rate "$fps"
  put_setting_safe secure refresh_rate_mode "$fps"
  put_setting_safe system thermal_limit_refresh_rate "$fps"
  put_setting_safe system NV_FPSLIMIT "$fps"
  run_cmd cmd display set-match-content-frame-rate-pref 1
  put_setting_safe system power.dfps.level 0
  put_setting_safe system disable_idle_fps true
  put_setting_safe system disable_idle_fps.threshold 1
  put_setting_safe system fps.idle_control false
  put_setting_safe system metadata_dynfps.disabel 1
  put_setting_safe system enable_dpps_dynamic_fps 0
  put_setting_safe system display.disable_dynamic_fps 1
  put_setting_safe system display.disable_metadata_dynamic_fps 1
  put_setting_safe system display.low_framerate_limit "$fps"
  put_setting_safe system display.defer_fps_frame_count 2
  put_setting_safe system display.refresh_rate "$fps"
  put_setting_safe system display.large_comp_hint_fps "$fps"
  put_setting_safe system display.enable_pref_hint_for_low_fps 1
  put_setting_safe system display.enable_optimal_refresh_rate 1
  put_setting_safe system display.enable_idle_content_fps_hint 0
  put_setting_safe system display.refresh_rate_changeable 0
  put_setting_safe system display.disable_mitigated_fps 1
  put_setting_safe system display.idle_time 0
  put_setting_safe system display.idle_time_inactive 0
  put_setting_safe global dfps.enable false
  put_setting_safe global smart_dfps.enable false
  put_setting_safe global fps.switch.thermal false
  put_setting_safe global fps.switch.default false
  put_setting_safe global smart_dfps.idle_fps "$fps"
  put_setting_safe global display.idle_default_fps "$fps"
  put_setting_safe global smart_dfps.app_switch_fps "$fps"
  put_setting_safe global display.fod_monitor_default_fps "$fps"
  put_setting_safe global tran_refresh_rate_video_detector.support 0
  put_setting_safe global tran_default_auto_refresh.support 0
  put_setting_safe global tran_default_refresh_mode "$fps"
  put_setting_safe global tran_low_battery_60hz_refresh_rate.support 0
  put_setting_safe global tran_90hz_refresh_rate.not_support 0
  put_setting_safe system surfaceflinger.idle_reduce_framerate_enable false
  put_setting_safe global tran_custom_refresh_rate_config.support 1
  put_setting_safe global transsion.frame_override.support 0
  put_setting_safe global transsion.tran_refresh_rate.support 0
  put_setting_safe global surface_flinger.use_content_detection_for_refresh_rate false
  put_setting_safe global media.recorder-max-base-layer-fps "$fps"
  put_setting_safe global vendor.fps.switch.default true
  put_setting_safe system vendor.disable_idle_fps true
  put_setting_safe global vendor.display.default_fps "$fps"
  put_setting_safe system vendor.display.idle_default_fps "$fps"
  put_setting_safe system vendor.display.enable_optimize_refresh 1
  put_setting_safe system vendor.display.video_or_camera_fps.support true
  put_setting_safe system game_driver_min_frame_rate "$fps"
  put_setting_safe system game_driver_max_frame_rate "$fps"
  put_setting_safe system game_driver_power_saving_mode 0
  put_setting_safe system game_driver_frame_skip_enable 0
  put_setting_safe system game_driver_vsync_enable 0
  put_setting_safe system game_driver_gpu_mode 1
  put_setting_safe system game_driver_fps_limit "$fps"
  put_setting_safe system user_refresh_rate "$fps"
  put_setting_safe system fps_limit "$fps"
  put_setting_safe system max_refresh_rate_for_ui "$fps"
  put_setting_safe system hwui_refresh_rate "$fps"
  put_setting_safe system display_refresh_rate "$fps"
  put_setting_safe system max_refresh_rate_for_gaming "$fps"
  put_setting_safe system fstb_target_fps_margin_high_fps 20
  put_setting_safe system fstb_target_fps_margin_low_fps 20
  put_setting_safe system gcc_fps_margin 10
  put_setting_safe display refresh_rate "$fps"
  put_setting_safe system sf.refresh_rate "$fps"
  put_setting_safe global refresh.active 1
  set_property_safe debug.sf.frame_rate_multiple_threshold "$fps"
  set_property_safe debug.sf.log_expensive_rendering true
  set_property_safe debug.sf.scroll_boost_refreshrate "$fps"
  set_property_safe debug.sf.touch_boost_refreshrate "$fps"
  set_property_safe debug.sf.high_speed_scroll_factor 25
  set_property_safe debug.sf.enable_refresh_rate_restriction_for_app_switch 1
  set_property_safe debug.mediatek_high_frame_rate_multiple_display_mode 0
  set_property_safe debug.mediatek_high_frame_rate_sf_set_big_core_fps_threshold "$fps"
  set_property_safe debug.hwui.refresh_rate "$fps"
  set_property_safe debug.sf.set_idle_timer_ms 500
  set_property_safe debug.sf.latch_unsignaled 1
  set_property_safe debug.sf.high_fps_early_phase_offset_ns 2000000
  set_property_safe debug.sf.high_fps_late_app_phase_offset_ns 500000
  set_property_safe debug.graphics.game_default_frame_rate "$fps"
  set_property_safe debug.graphics.game_default_frame_rate.disabled false
  set_property_safe persist.sys.gpu_perf_mode 1
  set_property_safe debug.mtk.powerhal.hint.bypass 1
  set_property_safe persist.sys.surfaceflinger.idle_reduce_framerate_enable false
  set_property_safe sys.surfaceflinger.idle_reduce_framerate_enable false
  set_property_safe debug.sf.perf_mode 1
  set_property_safe debug.hwui.disable_vsync true
  set_property_safe debug.performance.profile 1
  set_property_safe debug.perf.tuning 1
  set_property_safe debug.sys.display.fps "$fps"
  set_property_safe debug.sys.display_refresh_rate "$fps"
  set_property_safe debug.sys.game.minfps "$fps"
  set_property_safe debug.sys.game.maxfps "$fps"
  set_property_safe debug.sys.game.minframerate "$fps"
  set_property_safe debug.sys.game.maxframerate "$fps"
  set_property_safe debug.sys.min_refresh_rate "$fps"
  set_property_safe debug.sys.max_refresh_rate "$fps"
  set_property_safe debug.sys.peak_refresh_rate "$fps"
  set_property_safe debug.sys.sf.fps "$fps"
  set_property_safe debug.sys.smartfps 1
  set_property_safe debug.sys.vsync_optimization_enable false
  set_property_safe debug.sys.hwui.dyn_vsync 0
  set_property_safe debug.sys.vsync false
  set_property_safe debug.sys.hwui.fps_mode 1
  set_property_safe debug.sys.first.frame.accelerates true
  set_property_safe debug.sys.fps_unlock_allowed "$fps"
  set_property_safe debug.sys.display.max_fps "$fps"
  set_property_safe debug.sys.video.max.fps "$fps"
  set_property_safe debug.sys.surfaceflinger.idle_reduce_framerate_enable false
  set_property_safe sys.display.fps "$fps"
  set_property_safe sys.display_refresh_rate "$fps"
  set_property_safe sys.game.minfps "$fps"
  set_property_safe sys.game.maxfps "$fps"
  set_property_safe sys.game.minframerate "$fps"
  set_property_safe sys.game.maxframerate "$fps"
  set_property_safe sys.min_refresh_rate "$fps"
  set_property_safe sys.max_refresh_rate "$fps"
  set_property_safe sys.peak_refresh_rate "$fps"
  set_property_safe sys.sf.fps "$fps"
  set_property_safe sys.smartfps 1
  set_property_safe sys.vsync_optimization_enable false
  set_property_safe sys.hwui.dyn_vsync 0
  set_property_safe sys.vsync false
  set_property_safe sys.hwui.fps_mode 1
  set_property_safe sys.first.frame.accelerates true
  set_property_safe sys.fps_unlock_allowed "$fps"
  set_property_safe sys.display.max_fps "$fps"
  set_property_safe sys.video.max.fps "$fps"
  set_property_safe persist.vendor.display.refresh_rate "$fps"
}
apply_touch4() { put_setting_safe system pointer_speed 4; put_setting_safe system show_touches 0; put_setting_safe system haptic_feedback_enabled 1; }
apply_touch5() { put_setting_safe system pointer_speed 5; put_setting_safe system show_touches 0; put_setting_safe system haptic_feedback_enabled 1; }
apply_touch6() { put_setting_safe system pointer_speed 6; put_setting_safe system show_touches 0; put_setting_safe system haptic_feedback_enabled 1; }
apply_touch_headshot() { put_setting_safe system pointer_speed 5; put_setting_safe system show_touches 0; put_setting_safe system haptic_feedback_enabled 1; put_setting_safe system sound_effects_enabled 0; }
apply_input_balanced() { put_setting_safe system pointer_speed "$1"; put_setting_safe system show_touches 0; put_setting_safe system haptic_feedback_enabled 1; }
apply_input_feedback_off() { put_setting_safe system sound_effects_enabled 0; put_setting_safe system lockscreen_sounds_enabled 0; }
apply_gpu_safe() { put_setting_safe global game_driver_all_apps 1; put_setting_safe global updatable_driver_all_apps 1; put_setting_safe global gpu_debug_layers 0; put_setting_safe global enable_gpu_debug_layers 0; }
apply_gpu() { apply_gpu_safe; put_setting_safe global angle_gl_driver_all_angle 1; }
apply_vulkan_safe() { put_setting_safe global angle_gl_driver_all_angle 1; put_setting_safe global game_driver_all_apps 1; }
apply_memory_low() { put_setting_safe global cached_apps_freezer enabled; put_setting_safe global activity_manager_constants max_cached_processes=16; }
apply_memory_balanced() { put_setting_safe global cached_apps_freezer enabled; put_setting_safe global activity_manager_constants max_cached_processes=28; }
apply_memory_high() { put_setting_safe global cached_apps_freezer enabled; put_setting_safe global activity_manager_constants max_cached_processes=40; }
apply_storage_trim() { size="$1"; cmd package trim-caches "$size" >/dev/null 2>&1 || true; if [ "$ROOT_MODE" -eq 1 ]; then run_root "cmd package trim-caches $size"; run_root "sync"; fi; }
apply_storage_idle() { put_setting_safe global automatic_storage_manager_enabled 0; }
apply_dex_light() { if [ "$ROOT_MODE" -eq 1 ]; then run_root "cmd package bg-dexopt-job"; else cmd package bg-dexopt-job >/dev/null 2>&1 || true; fi; }
apply_private_dns() { host="$1"; put_setting_safe global private_dns_mode hostname; put_setting_safe global private_dns_specifier "$host"; }
apply_network_game() { put_setting_safe global mobile_data_always_on 1; put_setting_safe global wifi_scan_throttle_enabled 1; put_setting_safe global captive_portal_detection_enabled 1; }
apply_network_stream() { put_setting_safe global mobile_data_always_on 1; put_setting_safe global wifi_scan_throttle_enabled 1; }
apply_network_light() { put_setting_safe global wifi_scan_throttle_enabled 1; }
apply_mobile_stable() { put_setting_safe global mobile_data_always_on 1; put_setting_safe global network_recommendations_enabled 1; }
apply_wifi_stable() { put_setting_safe global wifi_scan_throttle_enabled 1; put_setting_safe global wifi_sleep_policy 2; }
apply_network_idle() { put_setting_safe global mobile_data_always_on 0; }
apply_battery_play() { put_setting_safe global low_power 0; put_setting_safe global adaptive_battery_management_enabled 1; }
apply_battery_idle() { put_setting_safe global adaptive_battery_management_enabled 1; put_setting_safe global app_standby_enabled 1; }
apply_battery_balanced() { put_setting_safe global adaptive_battery_management_enabled 1; put_setting_safe global low_power 0; }
apply_doze_light() { put_setting_safe global app_standby_enabled 1; put_setting_safe global forced_app_standby_enabled 1; }
apply_thermal_care() { put_setting_safe global low_power 0; put_setting_safe system screen_brightness_mode 1; }
apply_bt_audio() { put_setting_safe global bluetooth_on 1; put_setting_safe global ble_scan_always_enabled 1; }
apply_audio_stable() { put_setting_safe system sound_effects_enabled 0; put_setting_safe system haptic_feedback_enabled 1; }
apply_media_smooth() { put_setting_safe global media_metrics_mode 1; put_setting_safe system accelerometer_rotation 0; }
apply_charging_safe() { put_setting_safe global adaptive_charging_enabled 1; put_setting_safe global charging_vibration_enabled 0; }
apply_gps_maps() { put_setting_safe secure location_mode 3; put_setting_safe global assisted_gps_enabled 1; put_setting_safe global mobile_data_always_on 1; }
apply_hotspot_stable() { put_setting_safe global tether_offload_disabled 0; put_setting_safe global wifi_scan_throttle_enabled 1; }
apply_focus_light() { put_setting_safe global heads_up_notifications_enabled 1; put_setting_safe system notification_light_pulse 0; }
apply_tag_hint() { echo "Profile hint: $1" >/dev/null 2>&1 || true; }

notify "START: $MODULE_NAME running. $WATERMARK"
echo "[$MODULE_NAME] $WATERMARK"
echo "Mode: $([ "$ROOT_MODE" -eq 1 ] && echo root || echo non-root/adb-shell)"
apply_refresh120
apply_animation05
apply_gpu
apply_memory_balanced
if [ "$FAILED" -eq 0 ]; then
  notify "SUCCESS: applied safely in $([ "$ROOT_MODE" -eq 1 ] && echo root || echo non-root) mode. $WATERMARK"
  echo "SUCCESS: $MODULE_NAME applied safely ($COUNT commands). $WATERMARK"
else
  notify "DONE: $FAILED unsupported command(s) ignored. $WATERMARK"
  echo "DONE: $MODULE_NAME applied; $FAILED unsupported command(s) ignored. $WATERMARK"
fi
exit 0
