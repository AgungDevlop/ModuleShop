#!/system/bin/sh
MODULE_ID="aim_training_display_safe"
MODULE_NAME="Aim Training Display Safe"
TAG="AgungDeveloper"
WATERMARK="By Agung Developer"
BACKUP_DIR="/data/local/tmp/pluginmodule_backup"
BACKUP_FILE="$BACKUP_DIR/${MODULE_ID}.settings"
FAILED=0
COUNT=0
ROOT_MODE=0
mkdir -p "$BACKUP_DIR" >/dev/null 2>&1 || true
if [ "$(id -u 2>/dev/null)" = "0" ]; then ROOT_MODE=1; elif command -v su >/dev/null 2>&1 && su -c 'id -u' 2>/dev/null | grep -q '^0$'; then ROOT_MODE=1; fi
notify() { msg="$1"; cmd notification post -S bigtext -t "$MODULE_NAME | $WATERMARK" "$TAG" "$msg" >/dev/null 2>&1 || cmd notification post -t "$MODULE_NAME | $WATERMARK" "$TAG" "$msg" >/dev/null 2>&1 || true; }
run_cmd() { COUNT=$((COUNT + 1)); "$@" >/dev/null 2>&1 || FAILED=$((FAILED + 1)); }
run_root() { [ "$ROOT_MODE" -eq 1 ] || return 0; COUNT=$((COUNT + 1)); if [ "$(id -u 2>/dev/null)" = "0" ]; then sh -c "$*" >/dev/null 2>&1 || FAILED=$((FAILED + 1)); else su -c "$*" >/dev/null 2>&1 || FAILED=$((FAILED + 1)); fi; }
read_setting() { settings get "$1" "$2" 2>/dev/null; }
backup_setting() { ns="$1"; key="$2"; [ -f "$BACKUP_FILE" ] && grep -q "^$ns|$key|" "$BACKUP_FILE" 2>/dev/null && return 0; val="$(read_setting "$ns" "$key")"; echo "$ns|$key|$val" >> "$BACKUP_FILE" 2>/dev/null || true; }
put_setting_safe() { ns="$1"; key="$2"; val="$3"; backup_setting "$ns" "$key"; cur="$(read_setting "$ns" "$key")"; [ "$cur" = "$val" ] && return 0; run_cmd settings put "$ns" "$key" "$val"; if [ "$ROOT_MODE" -eq 1 ]; then run_root "settings put $ns $key '$val'"; fi; }
set_property_safe() { prop="$1"; val="$2"; if [ "$ROOT_MODE" -eq 1 ]; then run_root "setprop $prop '$val'"; fi; }
notify "START: $MODULE_NAME running. $WATERMARK"
echo "[$MODULE_NAME] $WATERMARK"
echo "Mode: $([ "$ROOT_MODE" -eq 1 ] && echo root || echo non-root/adb-shell)"
apply_refresh_balanced 120
apply_animation 0.25
apply_input_balanced 7
apply_input_feedback_off
apply_memory_balanced
if [ "$FAILED" -eq 0 ]; then
  notify "SUCCESS: applied safely in $([ "$ROOT_MODE" -eq 1 ] && echo root || echo non-root) mode. $WATERMARK"
  echo "SUCCESS: $MODULE_NAME applied safely ($COUNT commands). $WATERMARK"
else
  notify "DONE: $FAILED unsupported command(s) ignored. $WATERMARK"
  echo "DONE: $MODULE_NAME applied; $FAILED unsupported command(s) ignored. $WATERMARK"
fi
exit 0
