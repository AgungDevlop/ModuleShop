#!/system/bin/sh
MODULE_NAME="Unisoc Survival Safe"
MODULE_MODE="DEL"
TAG="PluginModule"
FAILED=0
COUNT=0
notify() { cmd notification post -S bigtext -t "$MODULE_NAME" "$TAG" "$1." >/dev/null 2>&1 || true; }
run_cmd() {
  COUNT=$((COUNT + 1))
  "$@" >/dev/null 2>&1 || FAILED=$((FAILED + 1))
}
put_setting() { run_cmd settings put "$1" "$2" "$3"; }
del_setting() { run_cmd settings delete "$1" "$2"; }
put_prop() { run_cmd setprop "$1" "$2"; }
notify "START ${MODULE_MODE}"
echo "[$MODULE_NAME] mode=$MODULE_MODE"
echo "Device: $(getprop ro.product.manufacturer) $(getprop ro.product.model)"
echo "Android: $(getprop ro.build.version.release) SDK $(getprop ro.build.version.sdk)"
del_setting "global" "game_mode"
del_setting "global" "game_dashboard_always_on"
del_setting "global" "game_driver_all_apps"
del_setting "global" "updatable_driver_all_apps"
del_setting "global" "angle_gl_driver_all_angle"
del_setting "global" "gpu_debug_layers"
del_setting "global" "window_animation_scale"
del_setting "global" "transition_animation_scale"
del_setting "global" "animator_duration_scale"
del_setting "system" "pointer_speed"
del_setting "system" "haptic_feedback_enabled"
del_setting "system" "show_touches"
del_setting "global" "low_power"
del_setting "global" "battery_saver_constants"
del_setting "global" "adaptive_battery_management_enabled"
del_setting "global" "peak_refresh_rate"
del_setting "global" "min_refresh_rate"
del_setting "system" "peak_refresh_rate"
del_setting "system" "min_refresh_rate"
del_setting "global" "activity_manager_constants"
if [ "$FAILED" -eq 0 ]; then
  notify "SUCCESS"
  echo "SUCCESS: $MODULE_NAME applied ($COUNT commands)."
  exit 0
else
  notify "FALSE"
  echo "FALSE: $MODULE_NAME completed with $FAILED unsupported command(s). Device/ROM may block some parameters."
  exit 0
fi
