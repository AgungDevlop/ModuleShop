#!/system/bin/sh
# Restore original settings for Hotspot Stability Safe. Watermark: By Agung Developer
MODULE_ID="hotspot_stability_safe"
MODULE_NAME="Hotspot Stability Safe"
TAG="AgungDeveloper"
WATERMARK="By Agung Developer"
BACKUP_FILE="/data/local/tmp/pluginmodule_backup/${MODULE_ID}.settings"
FAILED=0
COUNT=0
ROOT_MODE=0
if [ "$(id -u 2>/dev/null)" = "0" ]; then ROOT_MODE=1; elif command -v su >/dev/null 2>&1 && su -c 'id -u' 2>/dev/null | grep -q '^0$'; then ROOT_MODE=1; fi
notify() { cmd notification post -S bigtext -t "$MODULE_NAME | $WATERMARK" "$TAG" "$1" >/dev/null 2>&1 || cmd notification post -t "$MODULE_NAME | $WATERMARK" "$TAG" "$1" >/dev/null 2>&1 || true; }
run_cmd() { COUNT=$((COUNT + 1)); "$@" >/dev/null 2>&1 || FAILED=$((FAILED + 1)); }
run_root() { [ "$ROOT_MODE" -eq 1 ] || return 0; COUNT=$((COUNT + 1)); if [ "$(id -u 2>/dev/null)" = "0" ]; then sh -c "$*" >/dev/null 2>&1 || FAILED=$((FAILED + 1)); else su -c "$*" >/dev/null 2>&1 || FAILED=$((FAILED + 1)); fi; }
if [ -f "$BACKUP_FILE" ]; then
  while IFS='|' read -r ns key val; do
    [ -z "$ns" ] && continue
    if [ "$val" = "null" ] || [ -z "$val" ]; then
      run_cmd settings delete "$ns" "$key"
      [ "$ROOT_MODE" -eq 1 ] && run_root "settings delete $ns $key"
    else
      run_cmd settings put "$ns" "$key" "$val"
      [ "$ROOT_MODE" -eq 1 ] && run_root "settings put $ns $key '$val'"
    fi
  done < "$BACKUP_FILE"
  rm -f "$BACKUP_FILE" >/dev/null 2>&1 || true
  notify "RESTORED: $MODULE_NAME. $WATERMARK"
  echo "RESTORED: $MODULE_NAME ($COUNT commands). $WATERMARK"
else
  notify "No backup found. Nothing destructive done. $WATERMARK"
  echo "No backup found for $MODULE_NAME. Nothing destructive done. $WATERMARK"
fi
exit 0
