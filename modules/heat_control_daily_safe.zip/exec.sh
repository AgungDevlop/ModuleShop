#!/system/bin/sh
# Heat Control Daily Safe - Safe dual-mode ADB/root module v2.4.
# Watermark: By Agung Developer
# Rules: no cheat injection, no memory edit, no rm -rf, no pm clear, no force-stop, no thermal disable, no system/vendor writes.
MODULE_ID="heat_control_daily_safe"
MODULE_NAME="Heat Control Daily Safe"
TAG="AgungDeveloper"
WATERMARK="By Agung Developer"
BACKUP_DIR="/data/local/tmp/pluginmodule_backup"
BACKUP_FILE="$BACKUP_DIR/${MODULE_ID}.settings"
FAILED=0
COUNT=0
ROOT_MODE=0
mkdir -p "$BACKUP_DIR" >/dev/null 2>&1 || true

if [ "$(id -u 2>/dev/null)" = "0" ]; then
  ROOT_MODE=1
elif command -v su >/dev/null 2>&1 && su -c 'id -u' 2>/dev/null | grep -q '^0$'; then
  ROOT_MODE=1
fi

notify() {
  msg="$1"
  cmd notification post -S bigtext -t "$MODULE_NAME | $WATERMARK" "$TAG" "$msg" >/dev/null 2>&1 ||   cmd notification post -t "$MODULE_NAME | $WATERMARK" "$TAG" "$msg" >/dev/null 2>&1 || true
}
run_cmd() { COUNT=$((COUNT + 1)); "$@" >/dev/null 2>&1 || FAILED=$((FAILED + 1)); }
run_root() {
  [ "$ROOT_MODE" -eq 1 ] || return 0
  COUNT=$((COUNT + 1))
  if [ "$(id -u 2>/dev/null)" = "0" ]; then
    sh -c "$*" >/dev/null 2>&1 || FAILED=$((FAILED + 1))
  else
    su -c "$*" >/dev/null 2>&1 || FAILED=$((FAILED + 1))
  fi
}
read_setting() { settings get "$1" "$2" 2>/dev/null; }
backup_setting() {
  ns="$1"; key="$2"
  [ -f "$BACKUP_FILE" ] && grep -q "^$ns|$key|" "$BACKUP_FILE" 2>/dev/null && return 0
  val="$(read_setting "$ns" "$key")"
  echo "$ns|$key|$val" >> "$BACKUP_FILE" 2>/dev/null || true
}
put_setting_safe() {
  ns="$1"; key="$2"; val="$3"
  backup_setting "$ns" "$key"
  cur="$(read_setting "$ns" "$key")"
  [ "$cur" = "$val" ] && return 0
  run_cmd settings put "$ns" "$key" "$val"
  [ "$ROOT_MODE" -eq 1 ] && run_root "settings put $ns $key '$val'"
}
delete_setting_safe() { ns="$1"; key="$2"; backup_setting "$ns" "$key"; run_cmd settings delete "$ns" "$key"; [ "$ROOT_MODE" -eq 1 ] && run_root "settings delete $ns $key"; }

# Safe reusable profiles
animation_zero() { put_setting_safe global window_animation_scale 0; put_setting_safe global transition_animation_scale 0; put_setting_safe global animator_duration_scale 0; }
animation_fast() { put_setting_safe global window_animation_scale 0.5; put_setting_safe global transition_animation_scale 0.5; put_setting_safe global animator_duration_scale 0.5; }
refresh_safe() { fps="$1"; put_setting_safe global peak_refresh_rate "$fps"; put_setting_safe system peak_refresh_rate "$fps"; put_setting_safe global min_refresh_rate 60; put_setting_safe system min_refresh_rate 60; put_setting_safe global refresh_rate_mode 1; }
touch_balanced() { put_setting_safe system pointer_speed "$1"; put_setting_safe system show_touches 0; put_setting_safe system haptic_feedback_enabled 1; put_setting_safe system sound_effects_enabled 0; }
touch_visual_train() { put_setting_safe system show_touches 1; put_setting_safe system pointer_location 0; put_setting_safe system haptic_feedback_enabled 1; }
input_quiet() { put_setting_safe system sound_effects_enabled 0; put_setting_safe system lockscreen_sounds_enabled 0; }
gpu_safe() { put_setting_safe global game_driver_all_apps 1; put_setting_safe global updatable_driver_all_apps 1; put_setting_safe global gpu_debug_layers 0; put_setting_safe global enable_gpu_debug_layers 0; }
vulkan_safe() { put_setting_safe global angle_gl_driver_all_angle 1; put_setting_safe global game_driver_all_apps 1; }
network_stable() { put_setting_safe global mobile_data_always_on 1; put_setting_safe global wifi_scan_throttle_enabled 1; put_setting_safe global network_recommendations_enabled 1; }
wifi_stable() { put_setting_safe global wifi_scan_throttle_enabled 1; put_setting_safe global wifi_sleep_policy 2; }
dns_cloudflare() { put_setting_safe global private_dns_mode hostname; put_setting_safe global private_dns_specifier one.one.one.one; }
dns_google() { put_setting_safe global private_dns_mode hostname; put_setting_safe global private_dns_specifier dns.google; }
mem_balanced() { put_setting_safe global cached_apps_freezer enabled; put_setting_safe global activity_manager_constants max_cached_processes=28; }
mem_light() { put_setting_safe global cached_apps_freezer enabled; put_setting_safe global activity_manager_constants max_cached_processes=20; }
battery_balanced() { put_setting_safe global adaptive_battery_management_enabled 1; put_setting_safe global low_power 0; }
brightness_visibility() { put_setting_safe system screen_brightness_mode 0; }
eye_comfort() { put_setting_safe secure night_display_activated 1; put_setting_safe secure night_display_auto_mode 1; }
rotation_lock() { put_setting_safe system accelerometer_rotation 0; }
rotation_auto() { put_setting_safe system accelerometer_rotation 1; }
dnd_soft() { put_setting_safe global heads_up_notifications_enabled 0; }
notify_on() { put_setting_safe global heads_up_notifications_enabled 1; }
location_maps() { put_setting_safe secure location_mode 3; put_setting_safe global assisted_gps_enabled 1; put_setting_safe global mobile_data_always_on 1; }
audio_low_latency() { put_setting_safe system sound_effects_enabled 0; put_setting_safe system haptic_feedback_enabled 1; }
clipboard_safe() { put_setting_safe secure clipboard_show_access_notifications 1; }
privacy_indicators() { put_setting_safe secure camera_mic_icons_enabled 1; }
trim_light() { cmd package trim-caches 256M >/dev/null 2>&1 || true; [ "$ROOT_MODE" -eq 1 ] && run_root "cmd package trim-caches 256M; sync"; }
dex_light() { cmd package bg-dexopt-job >/dev/null 2>&1 || true; [ "$ROOT_MODE" -eq 1 ] && run_root "cmd package bg-dexopt-job"; }

notify "START: $MODULE_NAME running. $WATERMARK"
echo "[$MODULE_NAME] $WATERMARK"
echo "Mode: $([ "$ROOT_MODE" -eq 1 ] && echo root || echo non-root/adb-shell)"
apply_thermal_care
apply_refresh_balanced 90
apply_animation 0.5
apply_memory_balanced
apply_battery_balanced
if [ "$FAILED" -eq 0 ]; then
  notify "SUCCESS: applied safely in $([ "$ROOT_MODE" -eq 1 ] && echo root || echo non-root) mode. $WATERMARK"
  echo "SUCCESS: $MODULE_NAME applied safely ($COUNT commands). $WATERMARK"
else
  notify "DONE: $FAILED unsupported command(s) ignored. $WATERMARK"
  echo "DONE: $MODULE_NAME applied; $FAILED unsupported command(s) ignored. $WATERMARK"
fi
exit 0
