#!/system/bin/sh
BACKUP_DIR="/data/local/tmp/pluginmodule_backup"
BACKUP_FILE="$BACKUP_DIR/headshot_pro_gacor_safe.settings"
if [ -f "$BACKUP_FILE" ]; then
while IFS='|' read -r ns key val; do
[ -n "$ns" ] && [ -n "$key" ] && settings put "$ns" "$key" "$val" 2>/dev/null
done < "$BACKUP_FILE"
rm -f "$BACKUP_FILE" 2>/dev/null
fi
cmd notification post -t "Headshot Pro Gacor Safe" "AgungDeveloper" "Module removed" 2>/dev/null || true
exit 0
