#!/system/bin/sh
MODULE_ID="near_headshot_sensitivity_safe"
MODULE_NAME="Near Headshot Sensitivity Safe"
TAG="AgungDeveloper"
WATERMARK="By Agung Developer"
BACKUP_DIR="/data/local/tmp/pluginmodule_backup"
BACKUP_FILE="$BACKUP_DIR/${MODULE_ID}.settings"
FAILED=0
COUNT=0
ROOT_MODE=0
mkdir -p "$BACKUP_DIR" >/dev/null 2>&1 || true
if [ "$(id -u 2>/dev/null)" = "0" ]; then ROOT_MODE=1; elif command -v su >/dev/null 2>&1 && su -c 'id -u' 2>/dev/null | grep -q '^0$'; then ROOT_MODE=1; fi
notify() { msg="$1"; cmd notification post -S bigtext -t "$MODULE_NAME | $WATERMARK" "$TAG" "$msg" >/dev/null 2>&1 || cmd notification post -t "$MODULE_NAME | $WATERMARK" "$TAG" "$msg" >/dev/null 2>&1 || true; }
run_cmd() { COUNT=$((COUNT + 1)); "$@" >/dev/null 2>&1 || FAILED=$((FAILED + 1)); }
run_root() { [ "$ROOT_MODE" -eq 1 ] || return 0; COUNT=$((COUNT + 1)); if [ "$(id -u 2>/dev/null)" = "0" ]; then sh -c "$*" >/dev/null 2>&1 || FAILED=$((FAILED + 1)); else su -c "$*" >/dev/null 2>&1 || FAILED=$((FAILED + 1)); fi; }
read_setting() { settings get "$1" "$2" 2>/dev/null; }
backup_setting() { ns="$1"; key="$2"; [ -f "$BACKUP_FILE" ] && grep -q "^$ns|$key|" "$BACKUP_FILE" 2>/dev/null && return 0; val="$(read_setting "$ns" "$key")"; echo "$ns|$key|$val" >> "$BACKUP_FILE" 2>/dev/null || true; }
put_setting_safe() { ns="$1"; key="$2"; val="$3"; backup_setting "$ns" "$key"; cur="$(read_setting "$ns" "$key")"; [ "$cur" = "$val" ] && return 0; run_cmd settings put "$ns" "$key" "$val"; if [ "$ROOT_MODE" -eq 1 ]; then run_root "settings put $ns $key '$val'"; fi; }
set_property_safe() { prop="$1"; val="$2"; if [ "$ROOT_MODE" -eq 1 ]; then run_root "setprop $prop '$val'"; fi; }
notify "START: $MODULE_NAME. $WATERMARK"
refresh_rate=120
run_cmd cmd jobscheduler monitor-battery off
run_cmd cmd jobscheduler cache-config-changes off
run_cmd cmd power set-mode 0
put_setting_safe global low_power 0
put_setting_safe global peak_refresh_rate "$refresh_rate"
put_setting_safe system peak_refresh_rate "$refresh_rate"
put_setting_safe global min_refresh_rate "$refresh_rate"
put_setting_safe system min_refresh_rate "$refresh_rate"
put_setting_safe global refresh_rate_mode 1
put_setting_safe secure user_refresh_rate "$refresh_rate"
put_setting_safe secure miui_refresh_rate "$refresh_rate"
put_setting_safe system min_frame_rate "$refresh_rate"
put_setting_safe system max_frame_rate "$refresh_rate"
put_setting_safe system tran_refresh_mode "$refresh_rate"
put_setting_safe system last_tran_refresh_mode_in_refresh_setting "$refresh_rate"
put_setting_safe global min_fps "$refresh_rate"
put_setting_safe global max_fps "$refresh_rate"
put_setting_safe system tran_need_recovery_refresh_mode "$refresh_rate"
put_setting_safe system display_min_refresh_rate "$refresh_rate"
put_setting_safe system max_refresh_rate "$refresh_rate"
put_setting_safe secure refresh_rate_mode "$refresh_rate"
put_setting_safe system thermal_limit_refresh_rate "$refresh_rate"
put_setting_safe system NV_FPSLIMIT "$refresh_rate"
run_cmd cmd display set-match-content-frame-rate-pref 1
put_setting_safe system power.dfps.level 0
put_setting_safe system disable_idle_fps true
put_setting_safe system disable_idle_fps.threshold 1
put_setting_safe system fps.idle_control false
put_setting_safe system metadata_dynfps.disabel 1
put_setting_safe system enable_dpps_dynamic_fps 0
put_setting_safe system display.disable_dynamic_fps 1
put_setting_safe system display.disable_metadata_dynamic_fps 1
put_setting_safe system display.low_framerate_limit "$refresh_rate"
put_setting_safe system display.defer_fps_frame_count 2
put_setting_safe system display.refresh_rate "$refresh_rate"
put_setting_safe system display.large_comp_hint_fps "$refresh_rate"
put_setting_safe system display.enable_pref_hint_for_low_fps 1
put_setting_safe system display.enable_optimal_refresh_rate 1
put_setting_safe system display.enable_idle_content_fps_hint 0
put_setting_safe system display.refresh_rate_changeable 0
put_setting_safe system display.disable_mitigated_fps 1
put_setting_safe system display.idle_time 0
put_setting_safe system display.idle_time_inactive 0
put_setting_safe global dfps.enable false
put_setting_safe global smart_dfps.enable false
put_setting_safe global fps.switch.thermal false
put_setting_safe global fps.switch.default false
put_setting_safe global smart_dfps.idle_fps "$refresh_rate"
put_setting_safe global display.idle_default_fps "$refresh_rate"
put_setting_safe global smart_dfps.app_switch_fps "$refresh_rate"
put_setting_safe global display.fod_monitor_default_fps "$refresh_rate"
put_setting_safe global tran_refresh_rate_video_detector.support 0
put_setting_safe global tran_default_auto_refresh.support 0
put_setting_safe global tran_default_refresh_mode "$refresh_rate"
put_setting_safe global tran_low_battery_60hz_refresh_rate.support 0
put_setting_safe global tran_90hz_refresh_rate.not_support 0
put_setting_safe system surfaceflinger.idle_reduce_framerate_enable false
put_setting_safe global tran_custom_refresh_rate_config.support 1
put_setting_safe global transsion.frame_override.support 0
put_setting_safe global transsion.tran_refresh_rate.support 0
put_setting_safe global surface_flinger.use_content_detection_for_refresh_rate false
put_setting_safe global media.recorder-max-base-layer-fps "$refresh_rate"
put_setting_safe global vendor.fps.switch.default true
put_setting_safe system vendor.disable_idle_fps true
put_setting_safe global vendor.display.default_fps "$refresh_rate"
put_setting_safe system vendor.display.idle_default_fps "$refresh_rate"
put_setting_safe system vendor.display.enable_optimize_refresh 1
put_setting_safe system vendor.display.video_or_camera_fps.support true
put_setting_safe system game_driver_min_frame_rate "$refresh_rate"
put_setting_safe system game_driver_max_frame_rate "$refresh_rate"
put_setting_safe system game_driver_power_saving_mode 0
put_setting_safe system game_driver_frame_skip_enable 0
put_setting_safe system game_driver_vsync_enable 0
put_setting_safe system game_driver_gpu_mode 1
put_setting_safe system game_driver_fps_limit "$refresh_rate"
put_setting_safe system user_refresh_rate "$refresh_rate"
put_setting_safe system fps_limit "$refresh_rate"
put_setting_safe system max_refresh_rate_for_ui "$refresh_rate"
put_setting_safe system hwui_refresh_rate "$refresh_rate"
put_setting_safe system display_refresh_rate "$refresh_rate"
put_setting_safe system max_refresh_rate_for_gaming "$refresh_rate"
put_setting_safe system fstb_target_fps_margin_high_fps 20
put_setting_safe system fstb_target_fps_margin_low_fps 20
put_setting_safe system gcc_fps_margin 10
put_setting_safe display refresh_rate "$refresh_rate"
put_setting_safe system sf.refresh_rate "$refresh_rate"
put_setting_safe global window_animation_scale 0.5
put_setting_safe global transition_animation_scale 0.5
put_setting_safe global animator_duration_scale 0.5
put_setting_safe global game_driver_all_apps 1
put_setting_safe global updatable_driver_all_apps 1
put_setting_safe global gpu_debug_layers 0
put_setting_safe global enable_gpu_debug_layers 0
put_setting_safe global angle_gl_driver_all_angle 1
put_setting_safe system pointer_speed 5
put_setting_safe system show_touches 0
put_setting_safe system haptic_feedback_enabled 1
put_setting_safe system sound_effects_enabled 0
set_property_safe debug.sf.frame_rate_multiple_threshold "$refresh_rate"
set_property_safe debug.sf.log_expensive_rendering true
set_property_safe debug.sf.scroll_boost_refreshrate "$refresh_rate"
set_property_safe debug.sf.touch_boost_refreshrate "$refresh_rate"
set_property_safe debug.sf.high_speed_scroll_factor 25
set_property_safe debug.sf.enable_refresh_rate_restriction_for_app_switch 1
set_property_safe debug.mediatek_high_frame_rate_multiple_display_mode 0
set_property_safe debug.mediatek_high_frame_rate_sf_set_big_core_fps_threshold "$refresh_rate"
set_property_safe debug.hwui.refresh_rate "$refresh_rate"
set_property_safe debug.sf.set_idle_timer_ms 500
set_property_safe debug.sf.latch_unsignaled 1
set_property_safe debug.sf.high_fps_early_phase_offset_ns 2000000
set_property_safe debug.sf.high_fps_late_app_phase_offset_ns 500000
set_property_safe debug.graphics.game_default_frame_rate "$refresh_rate"
set_property_safe debug.graphics.game_default_frame_rate.disabled false
set_property_safe persist.sys.gpu_perf_mode 1
set_property_safe debug.mtk.powerhal.hint.bypass 1
set_property_safe persist.sys.surfaceflinger.idle_reduce_framerate_enable false
set_property_safe sys.surfaceflinger.idle_reduce_framerate_enable false
set_property_safe debug.sf.perf_mode 1
set_property_safe debug.hwui.disable_vsync true
set_property_safe debug.performance.profile 1
set_property_safe debug.perf.tuning 1
set_property_safe debug.sys.display.fps "$refresh_rate"
set_property_safe debug.sys.display_refresh_rate "$refresh_rate"
set_property_safe debug.sys.game.minfps "$refresh_rate"
set_property_safe debug.sys.game.maxfps "$refresh_rate"
set_property_safe debug.sys.game.minframerate "$refresh_rate"
set_property_safe debug.sys.game.maxframerate "$refresh_rate"
set_property_safe debug.sys.min_refresh_rate "$refresh_rate"
set_property_safe debug.sys.max_refresh_rate "$refresh_rate"
set_property_safe debug.sys.peak_refresh_rate "$refresh_rate"
set_property_safe debug.sys.sf.fps "$refresh_rate"
set_property_safe debug.sys.smartfps 1
set_property_safe debug.sys.vsync_optimization_enable false
set_property_safe debug.sys.hwui.dyn_vsync 0
set_property_safe debug.sys.vsync false
set_property_safe debug.sys.hwui.fps_mode 1
set_property_safe debug.sys.first.frame.accelerates true
set_property_safe debug.sys.fps_unlock_allowed "$refresh_rate"
set_property_safe debug.sys.display.max_fps "$refresh_rate"
set_property_safe debug.sys.video.max.fps "$refresh_rate"
set_property_safe debug.sys.surfaceflinger.idle_reduce_framerate_enable false
set_property_safe sys.display.fps "$refresh_rate"
set_property_safe sys.display_refresh_rate "$refresh_rate"
set_property_safe sys.game.minfps "$refresh_rate"
set_property_safe sys.game.maxfps "$refresh_rate"
set_property_safe sys.game.minframerate "$refresh_rate"
set_property_safe sys.game.maxframerate "$refresh_rate"
set_property_safe sys.min_refresh_rate "$refresh_rate"
set_property_safe sys.max_refresh_rate "$refresh_rate"
set_property_safe sys.peak_refresh_rate "$refresh_rate"
set_property_safe sys.sf.fps "$refresh_rate"
set_property_safe sys.smartfps 1
set_property_safe sys.vsync_optimization_enable false
set_property_safe sys.hwui.dyn_vsync 0
set_property_safe sys.vsync false
set_property_safe sys.hwui.fps_mode 1
set_property_safe sys.first.frame.accelerates true
set_property_safe sys.fps_unlock_allowed "$refresh_rate"
set_property_safe sys.display.max_fps "$refresh_rate"
set_property_safe sys.video.max.fps "$refresh_rate"
set_property_safe persist.vendor.display.refresh_rate "$refresh_rate"
put_setting_safe global refresh.active 1
if [ "$FAILED" -eq 0 ]; then notify "SUCCESS: $refresh_rate FPS UNLOCKED! $WATERMARK"; echo "SUCCESS: $MODULE_NAME ($COUNT). $WATERMARK"; else notify "DONE: $FAILED ignored. $WATERMARK"; echo "DONE: $MODULE_NAME; $FAILED ignored. $WATERMARK"; fi
exit 0