Plugin Catalog Modules v2.3 Dual Safe - By Agung Developer

Isi:
- 98 modul ZIP di folder modules/
- Semua modul support non-root/root otomatis.
- Jika dijalankan dari adb shell non-root: pakai settings/cmd aman.
- Jika root/su tersedia: menjalankan tambahan root-safe seperti settings via su, trim cache ringan, sync, dan dex maintenance hanya di modul yang relevan.

Watermark notifikasi:
- Semua exec.sh dan del.sh memakai cmd notification post dengan title berisi: By Agung Developer.
- Jika ROM tidak support cmd notification, modul tetap jalan dan hanya melewati notifikasi.

Aturan aman:
- Tidak ada rm -rf
- Tidak ada pm clear
- Tidak ada am force-stop
- Tidak ada reboot
- Tidak disable thermal
- Tidak menulis system/vendor partition
- Refresh rate tidak dikunci brutal: peak sesuai profil, min tetap 60 agar UI tidak freeze.

Cara pakai via ADB:
adb shell sh /path/exec.sh
adb shell sh /path/del.sh

Jika root ada, script mendeteksi otomatis via id -u atau su -c id -u.
