AgungDevlop/ModuleShop upload package
=====================================
1. Upload plugins.json to the root of repo ModuleShop.
2. Upload every ZIP inside modules/ to repo folder modules/.
3. Easier method: upload module_upload_bundle.zip to the repo root, then run GitHub Actions workflow "Unpack ModuleShop ZIP".
4. Raw JSON used by Kotlin:
   https://raw.githubusercontent.com/AgungDevlop/ModuleShop/main/plugins.json

Safety notes:
- Module ZIPs contain only exec.sh and del.sh.
- No su, no adb command string, no wipe/format, no rm -rf, no pm clear, no reboot.
- Some settings/setprop keys are OEM-specific; unsupported keys will fail harmlessly and the script reports it.
