Plugin Catalog Modules v2.4 Dual Safe + Helper Pack - By Agung Developer

Isi:
- 128 modul ZIP di folder modules/
- Semua modul support non-root/root otomatis.
- Non-root/ADB shell: memakai settings/cmd aman.
- Root/su tersedia: memakai jalur tambahan root-safe yang tetap dibatasi.

Update v2.4:
- Menambahkan Aim Helper aman seperti Easy Headshot Touch Safe, Near Headshot Sensitivity Safe, Drag Headshot Free Fire Safe, ADS Snap Touch Safe, Gyro Stability Helper, Recoil Control Feel, dan modul bantuan kontrol lainnya.
- Catatan penting: modul Aim Helper ini bukan auto-aim, bukan aimbot, bukan macro, bukan memory edit, bukan mod game. Hanya optimasi sistem layar, sentuhan, refresh, GPU hint, dan network stability supaya kontrol terasa lebih responsif.
- Menambahkan helper harian: study focus, meeting, maps driver, privacy indicator, QR payment, creator/live, screen record, old phone rescue, heat control, typing, download/upload.

Watermark notifikasi:
- Semua module baru memakai cmd notification post dengan title: By Agung Developer.
- Jika ROM tidak support cmd notification, script tetap lanjut tanpa crash.

Batas aman:
- Tidak ada rm -rf
- Tidak ada pm clear
- Tidak ada am force-stop
- Tidak disable thermal
- Tidak sentuh partisi system/vendor
- Tidak inject game, tidak edit memory, tidak auto aim
- del.sh restore setting awal dari /data/local/tmp/pluginmodule_backup/
